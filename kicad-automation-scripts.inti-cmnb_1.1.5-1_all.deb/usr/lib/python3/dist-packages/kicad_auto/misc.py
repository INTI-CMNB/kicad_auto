# Default W,H for recording
REC_W=1366
REC_H=768

__version__ ='1.1.5'
