"""
KiPlot errors
"""


class KiPlotError(Exception):
    pass
